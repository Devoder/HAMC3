
'use client';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-16 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900/20 to-gray-900"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center overflow-hidden shadow-lg hover:scale-110 transition-transform duration-300">
                <img 
                  src="https://static.readdy.ai/image/b896614e4e994fc4334edc54b5d3d86e/c8d2584ee296c1d839e8c6e0ef708469.png" 
                  alt="HAMC Logo" 
                  className="w-10 h-10 object-contain"
                />
              </div>
              <span className="text-2xl font-bold">Caxilharia Angola</span>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Especialistas em caxilharia e alumínio com qualidade garantida e atendimento personalizado em toda Angola.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://instagram.com/caxilhariaangola" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center hover:scale-110 transition-all duration-300 cursor-pointer shadow-lg hover:shadow-pink-500/25"
              >
                <i className="ri-instagram-line text-white text-xl"></i>
              </a>
              <a 
                href="https://facebook.com/hamc_servicos" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-700 rounded-full flex items-center justify-center hover:scale-110 transition-all duration-300 cursor-pointer shadow-lg hover:shadow-blue-500/25"
              >
                <i className="ri-facebook-fill text-white text-xl"></i>
              </a>
              <a 
                href="https://wa.me/244930231558" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-700 rounded-full flex items-center justify-center hover:scale-110 transition-all duration-300 cursor-pointer shadow-lg hover:shadow-green-500/25"
              >
                <i className="ri-whatsapp-line text-white text-xl"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-6 text-white">Nossos Serviços</h3>
            <ul className="space-y-3 text-gray-300">
              <li>
                <a href="#" className="hover:text-blue-400 transition-colors cursor-pointer flex items-center space-x-2">
                  <i className="ri-window-line text-blue-400"></i>
                  <span>Janelas de Alumínio</span>
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-blue-400 transition-colors cursor-pointer flex items-center space-x-2">
                  <i className="ri-door-line text-blue-400"></i>
                  <span>Portas de Alumínio</span>
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-blue-400 transition-colors cursor-pointer flex items-center space-x-2">
                  <i className="ri-shield-line text-blue-400"></i>
                  <span>Grades de Segurança</span>
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-blue-400 transition-colors cursor-pointer flex items-center space-x-2">
                  <i className="ri-building-line text-blue-400"></i>
                  <span>Fachadas Completas</span>
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-6 text-white">Contacto</h3>
            <ul className="space-y-4 text-gray-300">
              <li className="flex items-center space-x-3 hover:text-green-400 transition-colors">
                <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
                  <i className="ri-whatsapp-line text-white"></i>
                </div>
                <span>+244 930 231 558</span>
              </li>
              <li className="flex items-center space-x-3 hover:text-blue-400 transition-colors">
                <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                  <i className="ri-mail-line text-white"></i>
                </div>
                <span>contato@caxilhariaangola.ao</span>
              </li>
              <li className="flex items-center space-x-3 hover:text-red-400 transition-colors">
                <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center">
                  <i className="ri-map-pin-line text-white"></i>
                </div>
                <span>Luanda, Angola</span>
              </li>
              <li className="flex items-center space-x-3 hover:text-orange-400 transition-colors">
                <div className="w-10 h-10 bg-orange-600 rounded-full flex items-center justify-center">
                  <i className="ri-time-line text-white"></i>
                </div>
                <span>Seg-Sex: 8h-17h, Sáb: 8h-12h</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8 text-center text-gray-400">
          <p className="text-lg">&copy; 2024 Caxilharia Angola - HAMC. Todos os direitos reservados.</p>
          <p className="mt-2 text-sm">Desenvolvido com ❤️ por Readdy.ai</p>
        </div>
      </div>
    </footer>
  );
}
