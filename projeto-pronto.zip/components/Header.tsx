
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white/95 backdrop-blur-md shadow-lg border-b sticky top-0 z-50 transition-all duration-300">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-3 group">
            <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center overflow-hidden shadow-lg group-hover:scale-110 transition-transform duration-300">
              <img 
                src="https://static.readdy.ai/image/b896614e4e994fc4334edc54b5d3d86e/c8d2584ee296c1d839e8c6e0ef708469.png" 
                alt="HAMC Logo" 
                className="w-12 h-12 object-contain"
              />
            </div>
            <span className="text-xl font-bold text-gray-800 group-hover:text-blue-600 transition-colors">
              Caxilharia Angola
            </span>
          </Link>
          
          <nav className="hidden md:flex space-x-8">
            <Link 
              href="#portfolio" 
              className="text-gray-600 hover:text-blue-600 transition-all duration-300 hover:scale-105 cursor-pointer font-medium"
            >
              Portfólio
            </Link>
            <Link 
              href="#servicos" 
              className="text-gray-600 hover:text-blue-600 transition-all duration-300 hover:scale-105 cursor-pointer font-medium"
            >
              Serviços
            </Link>
            <Link 
              href="#orcamento" 
              className="text-gray-600 hover:text-blue-600 transition-all duration-300 hover:scale-105 cursor-pointer font-medium"
            >
              Orçamento
            </Link>
            <Link 
              href="#contato" 
              className="text-gray-600 hover:text-blue-600 transition-all duration-300 hover:scale-105 cursor-pointer font-medium"
            >
              Contato
            </Link>
          </nav>
          
          <button 
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <i className={`ri-${isMenuOpen ? 'close' : 'menu'}-line text-2xl transition-transform duration-300`}></i>
          </button>
        </div>

        {/* Mobile Menu */}
        <div className={`md:hidden overflow-hidden transition-all duration-300 ${isMenuOpen ? 'max-h-64 opacity-100' : 'max-h-0 opacity-0'}`}>
          <nav className="py-4 space-y-2">
            <Link 
              href="#portfolio" 
              className="block px-4 py-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all cursor-pointer"
              onClick={() => setIsMenuOpen(false)}
            >
              Portfólio
            </Link>
            <Link 
              href="#servicos" 
              className="block px-4 py-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all cursor-pointer"
              onClick={() => setIsMenuOpen(false)}
            >
              Serviços
            </Link>
            <Link 
              href="#orcamento" 
              className="block px-4 py-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all cursor-pointer"
              onClick={() => setIsMenuOpen(false)}
            >
              Orçamento
            </Link>
            <Link 
              href="#contato" 
              className="block px-4 py-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all cursor-pointer"
              onClick={() => setIsMenuOpen(false)}
            >
              Contato
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
