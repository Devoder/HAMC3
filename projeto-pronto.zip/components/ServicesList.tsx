
'use client';

import { useState } from 'react';

export default function ServicesList() {
  const [hoveredService, setHoveredService] = useState<number | null>(null);

  const services = [
    {
      id: 1,
      name: "Janelas de Alumínio",
      description: "Janelas modernas e resistentes para sua casa ou escritório",
      image: "https://readdy.ai/api/search-image?query=Modern%20aluminum%20windows%20installation%20service%20in%20Angola%2C%20sleek%20metallic%20frames%20with%20glass%20panels%2C%20residential%20and%20commercial%20window%20solutions%2C%20professional%20craftsmanship%2C%20contemporary%20design%20with%20clean%20lines%20and%20durable%20materials&width=400&height=300&seq=serv-001&orientation=landscape",
      priceRange: "25.000 - 80.000 Kz",
      icon: "ri-window-line",
      features: ["Resistente ao clima", "Isolamento térmico", "Fácil manutenção"]
    },
    {
      id: 2,
      name: "Portas de Alumínio",
      description: "Portas de entrada e internas com acabamento premium",
      image: "https://readdy.ai/api/search-image?query=Aluminum%20doors%20installation%20service%20in%20Angola%2C%20elegant%20entrance%20doors%20with%20metallic%20finish%2C%20commercial%20and%20residential%20door%20solutions%2C%20modern%20architectural%20design%2C%20high-quality%20craftsmanship%20and%20security%20features&width=400&height=300&seq=serv-002&orientation=landscape",
      priceRange: "35.000 - 120.000 Kz",
      icon: "ri-door-line",
      features: ["Segurança máxima", "Design moderno", "Durabilidade"]
    },
    {
      id: 3,
      name: "Grades de Segurança",
      description: "Proteção elegante e segura para janelas e portas",
      image: "https://readdy.ai/api/search-image?query=Security%20aluminum%20grilles%20and%20bars%20installation%20in%20Angola%2C%20protective%20window%20guards%2C%20decorative%20security%20solutions%2C%20residential%20safety%20systems%2C%20elegant%20metalwork%20with%20professional%20installation%20quality&width=400&height=300&seq=serv-003&orientation=landscape",
      priceRange: "15.000 - 60.000 Kz",
      icon: "ri-shield-line",
      features: ["Proteção total", "Estética preservada", "Fácil instalação"]
    },
    {
      id: 4,
      name: "Fachadas Completas",
      description: "Transformação total da fachada do seu edifício",
      image: "https://readdy.ai/api/search-image?query=Complete%20aluminum%20facade%20renovation%20service%20in%20Angola%2C%20modern%20building%20exterior%20transformation%2C%20curtain%20wall%20systems%2C%20architectural%20cladding%2C%20contemporary%20commercial%20building%20design%20with%20metallic%20finish&width=400&height=300&seq=serv-004&orientation=landscape",
      priceRange: "150.000 - 250.000 Kz",
      icon: "ri-building-line",
      features: ["Projeto completo", "Valorização imobiliária", "Garantia estendida"]
    },
    {
      id: 5,
      name: "Divisórias de Escritório",
      description: "Ambientes corporativos modernos e funcionais",
      image: "https://readdy.ai/api/search-image?query=Office%20aluminum%20partitions%20installation%20service%20in%20Angola%2C%20modern%20workplace%20dividers%2C%20glass%20and%20aluminum%20office%20separations%2C%20contemporary%20corporate%20interior%20design%2C%20professional%20workspace%20solutions&width=400&height=300&seq=serv-005&orientation=landscape",
      priceRange: "40.000 - 100.000 Kz",
      icon: "ri-layout-line",
      features: ["Flexibilidade", "Isolamento acústico", "Instalação rápida"]
    },
    {
      id: 6,
      name: "Esquadrias Personalizadas",
      description: "Projetos únicos desenvolvidos sob medida",
      image: "https://readdy.ai/api/search-image?query=Custom%20aluminum%20framing%20service%20in%20Angola%2C%20bespoke%20metalwork%20solutions%2C%20personalized%20architectural%20elements%2C%20artisan%20craftsmanship%2C%20unique%20design%20installations%20with%20precision%20engineering&width=400&height=300&seq=serv-006&orientation=landscape",
      priceRange: "50.000 - 200.000 Kz",
      icon: "ri-hammer-line",
      features: ["Totalmente personalizado", "Design exclusivo", "Acabamento premium"]
    }
  ];

  return (
    <section id="servicos" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            Nossos Serviços
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Oferecemos soluções completas em caxilharia e alumínio com qualidade premium
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={service.id} 
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 transform hover:scale-105 cursor-pointer"
              style={{ animationDelay: `${index * 0.1}s` }}
              onMouseEnter={() => setHoveredService(service.id)}
              onMouseLeave={() => setHoveredService(null)}
            >
              <div className="relative overflow-hidden">
                <img 
                  src={service.image}
                  alt={service.name}
                  className="w-full h-48 object-cover object-top transition-transform duration-500 hover:scale-110"
                />
                <div className="absolute top-4 left-4 w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center shadow-lg">
                  <i className={`${service.icon} text-white text-xl`}></i>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-2">
                  {service.name}
                </h3>
                <p className="text-gray-600 mb-4 leading-relaxed">
                  {service.description}
                </p>
                
                <div className="mb-4">
                  <div className="flex flex-wrap gap-2">
                    {service.features.map((feature, idx) => (
                      <span 
                        key={idx} 
                        className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="text-lg font-semibold text-blue-600">
                    {service.priceRange}
                  </div>
                  <button 
                    onClick={() => {
                      const message = encodeURIComponent(`Olá! Gostaria de um orçamento para: ${service.name}`);
                      window.open(`https://wa.me/244930231558?text=${message}`, '_blank');
                    }}
                    className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 whitespace-nowrap ${
                      hoveredService === service.id 
                        ? 'bg-gradient-to-r from-green-500 to-green-600 text-white shadow-lg scale-105' 
                        : 'bg-green-600 text-white hover:bg-green-700'
                    }`}
                  >
                    <i className="ri-whatsapp-line mr-2"></i>
                    Pedir Orçamento
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">
              Não encontrou o que procura?
            </h3>
            <p className="text-lg mb-6 text-blue-100">
              Fazemos projetos personalizados para atender suas necessidades específicas
            </p>
            <button 
              onClick={() => {
                const message = encodeURIComponent("Olá! Preciso de um projeto personalizado de caxilharia. Podem me ajudar?");
                window.open(`https://wa.me/244930231558?text=${message}`, '_blank');
              }}
              className="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:bg-blue-50 transition-all duration-300 transform hover:scale-105 cursor-pointer inline-flex items-center space-x-2"
            >
              <i className="ri-chat-3-line text-xl"></i>
              <span>Falar com Especialista</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
