
'use client';

import { useState } from 'react';

export default function Contact() {
  const [formData, setFormData] = useState({
    nome: '',
    telefone: '',
    email: '',
    servico: '',
    mensagem: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    const { nome, telefone, email, servico, mensagem } = formData;
    
    if (!nome.trim()) {
      alert('Por favor, preencha o nome completo');
      return false;
    }
    
    if (!telefone.trim()) {
      alert('Por favor, preencha o telefone');
      return false;
    }
    
    if (!email.trim() || !email.includes('@')) {
      alert('Por favor, preencha um email válido');
      return false;
    }
    
    if (!servico) {
      alert('Por favor, selecione um serviço');
      return false;
    }
    
    if (!mensagem.trim()) {
      alert('Por favor, escreva uma mensagem');
      return false;
    }
    
    if (mensagem.length > 500) {
      alert('A mensagem não pode ter mais de 500 caracteres');
      return false;
    }
    
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    setSubmitStatus('idle');
    
    try {
      // Simular envio por 2 segundos
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const message = encodeURIComponent(
        `Olá! Segue minha mensagem de contato:\n\n` +
        `Nome: ${formData.nome}\n` +
        `Telefone: ${formData.telefone}\n` +
        `Email: ${formData.email}\n` +
        `Serviço: ${formData.servico}\n` +
        `Mensagem: ${formData.mensagem}`
      );
      
      window.open(`https://wa.me/244930231558?text=${message}`, '_blank');
      
      setSubmitStatus('success');
      
      // Limpar formulário após sucesso
      setFormData({
        nome: '',
        telefone: '',
        email: '',
        servico: '',
        mensagem: ''
      });
      
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contato" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6 animate-fade-in">
            Contatos
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Entre em contato conosco para mais informações
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="space-y-8">
            <div className="flex items-start space-x-4 animate-slide-in-left">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <i className="ri-whatsapp-line text-green-600 text-xl"></i>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">WhatsApp</h3>
                <p className="text-gray-600 mb-2">+244 930 231 558</p>
                <button 
                  onClick={() => window.open('https://wa.me/244930231558', '_blank')}
                  className="text-green-600 hover:text-green-700 font-medium cursor-pointer"
                >
                  Conversar Agora
                </button>
              </div>
            </div>

            <div className="flex items-start space-x-4 animate-slide-in-left">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <i className="ri-mail-line text-blue-600 text-xl"></i>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">E-mail</h3>
                <p className="text-gray-600">contato@caxilhariaangola.ao</p>
              </div>
            </div>

            <div className="flex items-start space-x-4 animate-slide-in-left">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <i className="ri-time-line text-orange-600 text-xl"></i>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Horário de Funcionamento</h3>
                <p className="text-gray-600">Segunda a Sexta: 8h00 - 17h00</p>
                <p className="text-gray-600">Sábado: 8h00 - 12h00</p>
              </div>
            </div>

            <div className="flex items-start space-x-4 animate-slide-in-left">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <i className="ri-facebook-fill text-purple-600 text-xl"></i>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Facebook</h3>
                <button 
                  onClick={() => window.open('https://facebook.com/hamc_servicos', '_blank')}
                  className="text-purple-600 hover:text-purple-700 font-medium cursor-pointer"
                >
                  @hamc_servicos
                </button>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-8 animate-slide-in-right">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Envie uma Mensagem</h3>
            
            {submitStatus === 'success' && (
              <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                <i className="ri-check-circle-line mr-2"></i>
                Mensagem enviada com sucesso! Redirecionando para WhatsApp...
              </div>
            )}
            
            {submitStatus === 'error' && (
              <div className="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                <i className="ri-error-warning-line mr-2"></i>
                Erro ao enviar mensagem. Tente novamente.
              </div>
            )}
            
            <form id="contact-form" onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="nome" className="block text-sm font-medium text-gray-700 mb-1">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  id="nome"
                  name="nome"
                  value={formData.nome}
                  onChange={handleInputChange}
                  required
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  placeholder="Seu nome completo"
                />
              </div>

              <div>
                <label htmlFor="telefone" className="block text-sm font-medium text-gray-700 mb-1">
                  Telefone *
                </label>
                <input
                  type="tel"
                  id="telefone"
                  name="telefone"
                  value={formData.telefone}
                  onChange={handleInputChange}
                  required
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  placeholder="Seu número de telefone"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  E-mail *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  placeholder="seu@email.com"
                />
              </div>

              <div>
                <label htmlFor="servico" className="block text-sm font-medium text-gray-700 mb-1">
                  Serviço Desejado *
                </label>
                <div className="relative">
                  <select
                    id="servico"
                    name="servico"
                    value={formData.servico}
                    onChange={handleInputChange}
                    required
                    disabled={isSubmitting}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm appearance-none pr-8 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <option value="">Selecione um serviço</option>
                    <option value="Janelas de Alumínio">Janelas de Alumínio</option>
                    <option value="Portas de Alumínio">Portas de Alumínio</option>
                    <option value="Grades de Segurança">Grades de Segurança</option>
                    <option value="Fachadas Completas">Fachadas Completas</option>
                    <option value="Divisórias de Escritório">Divisórias de Escritório</option>
                    <option value="Esquadrias Personalizadas">Esquadrias Personalizadas</option>
                  </select>
                  <i className="ri-arrow-down-s-line absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                </div>
              </div>

              <div>
                <label htmlFor="mensagem" className="block text-sm font-medium text-gray-700 mb-1">
                  Mensagem *
                </label>
                <textarea
                  id="mensagem"
                  name="mensagem"
                  value={formData.mensagem}
                  onChange={handleInputChange}
                  rows={4}
                  maxLength={500}
                  required
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm resize-none transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  placeholder="Descreva seu projeto ou dúvida..."
                ></textarea>
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>Máximo 500 caracteres</span>
                  <span>{formData.mensagem.length}/500</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-700 transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
              >
                {isSubmitting ? (
                  <>
                    <i className="ri-loader-2-line animate-spin mr-2"></i>
                    Enviando...
                  </>
                ) : (
                  'Enviar Mensagem'
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
