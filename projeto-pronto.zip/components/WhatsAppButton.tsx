'use client';

export default function WhatsAppButton() {
  const handleClick = () => {
    const message = encodeURIComponent("Olá! Gostaria de conversar sobre serviços de caxilharia.");
    window.open(`https://wa.me/244930231558?text=${message}`, '_blank');
  };

  return (
    <button
      onClick={handleClick}
      className="fixed bottom-6 right-6 bg-green-600 hover:bg-green-700 text-white p-4 rounded-full shadow-lg transition-all duration-300 hover:scale-110 z-50 cursor-pointer animate-bounce"
      aria-label="Conversar no WhatsApp"
    >
      <i className="ri-whatsapp-line text-2xl"></i>
    </button>
  );
}