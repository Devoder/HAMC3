
'use client';

import { useState } from 'react';

interface ServiceItem {
  id: number;
  name: string;
  quantity: number;
  materials: 'nossos' | 'cliente';
  basePrice: number;
}

export default function ServiceRequest() {
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [showInvoice, setShowInvoice] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [invoiceStatus, setInvoiceStatus] = useState<'idle' | 'generated' | 'sent'>('idle');
  
  const serviceOptions = [
    { id: 1, name: 'Janelas de Alumínio', basePrice: 45000 },
    { id: 2, name: 'Portas de Alumínio', basePrice: 65000 },
    { id: 3, name: 'Grades de Segurança', basePrice: 25000 },
    { id: 4, name: 'Fachadas Completas', basePrice: 180000 },
    { id: 5, name: 'Divisórias de Escritório', basePrice: 55000 },
    { id: 6, name: 'Esquadrias Personalizadas', basePrice: 85000 }
  ];

  const addService = () => {
    const newService: ServiceItem = {
      id: Date.now(),
      name: '',
      quantity: 1,
      materials: 'nossos',
      basePrice: 0
    };
    setServices([...services, newService]);
  };

  const updateService = (id: number, field: keyof ServiceItem, value: any) => {
    setServices(services.map(service => {
      if (service.id === id) {
        const updated = { ...service, [field]: value };
        if (field === 'name') {
          const selectedService = serviceOptions.find(opt => opt.name === value);
          if (selectedService) {
            updated.basePrice = selectedService.basePrice;
          }
        }
        return updated;
      }
      return service;
    }));
  };

  const removeService = (id: number) => {
    setServices(services.filter(service => service.id !== id));
  };

  const calculateServiceTotal = (service: ServiceItem) => {
    if (!service.name || !service.basePrice) return 0;
    const materialMultiplier = service.materials === 'nossos' ? 1 : 0.7;
    return service.basePrice * service.quantity * materialMultiplier;
  };

  const calculateTotal = () => {
    return services.reduce((total, service) => total + calculateServiceTotal(service), 0);
  };

  const validateForm = () => {
    if (!clientName.trim()) {
      alert('Por favor, preencha o nome do cliente');
      return false;
    }
    
    if (!clientPhone.trim()) {
      alert('Por favor, preencha o telefone do cliente');
      return false;
    }
    
    if (services.length === 0) {
      alert('Por favor, adicione pelo menos um serviço');
      return false;
    }
    
    for (const service of services) {
      if (!service.name) {
        alert('Por favor, selecione o tipo de serviço para todos os itens');
        return false;
      }
      
      if (service.quantity < 1) {
        alert('A quantidade deve ser pelo menos 1');
        return false;
      }
    }
    
    return true;
  };

  const generateInvoice = async () => {
    if (!validateForm()) return;
    
    setIsGenerating(true);
    
    try {
      // Simular geração de fatura
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setShowInvoice(true);
      setInvoiceStatus('generated');
      
    } catch (error) {
      alert('Erro ao gerar fatura. Tente novamente.');
    } finally {
      setIsGenerating(false);
    }
  };

  const sendInvoiceWhatsApp = async () => {
    setIsSending(true);
    
    try {
      // Simular envio
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const servicesList = services.map(service => 
        `• ${service.name} (${service.quantity}x) - Materiais: ${service.materials === 'nossos' ? 'Nossos' : 'Cliente'} - ${calculateServiceTotal(service).toLocaleString()} Kz`
      ).join('\n');
      
      const message = encodeURIComponent(
        `FATURA DE SERVIÇOS - HAMC\n\n` +
        `Cliente: ${clientName}\n` +
        `Telefone: ${clientPhone}\n\n` +
        `SERVIÇOS:\n${servicesList}\n\n` +
        `TOTAL A PAGAR: ${calculateTotal().toLocaleString()} Kz\n\n` +
        `Esta fatura será confirmada após encontro presencial.\n` +
        `Obrigado pela preferência!`
      );
      
      window.open(`https://wa.me/244930231558?text=${message}`, '_blank');
      
      setInvoiceStatus('sent');
      
    } catch (error) {
      alert('Erro ao enviar fatura. Tente novamente.');
    } finally {
      setIsSending(false);
    }
  };

  const resetForm = () => {
    setClientName('');
    setClientPhone('');
    setServices([]);
    setShowInvoice(false);
    setInvoiceStatus('idle');
  };

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6 animate-fade-in">
            Pedido de Serviços
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Liste todos os serviços que precisa e gere sua fatura automaticamente
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {invoiceStatus === 'sent' && (
            <div className="mb-8 p-6 bg-green-100 border border-green-400 text-green-700 rounded-lg text-center">
              <i className="ri-check-circle-line text-2xl mb-2 block"></i>
              <h3 className="text-lg font-semibold mb-2">Fatura Enviada com Sucesso!</h3>
              <p className="mb-4">A fatura foi enviada para o WhatsApp. Aguarde nosso contato para confirmar o encontro presencial.</p>
              <button 
                onClick={resetForm}
                className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors cursor-pointer"
              >
                Fazer Novo Pedido
              </button>
            </div>
          )}

          <div className="bg-gray-50 rounded-lg p-8 mb-8">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Dados do Cliente</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  disabled={isGenerating || isSending}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  placeholder="Digite seu nome completo"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Telefone *
                </label>
                <input
                  type="tel"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  disabled={isGenerating || isSending}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  placeholder="Digite seu telefone"
                />
              </div>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-8 mb-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-gray-800">Lista de Serviços</h3>
              <button
                onClick={addService}
                disabled={isGenerating || isSending}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <i className="ri-add-line mr-2"></i>
                Adicionar Serviço
              </button>
            </div>

            {services.length === 0 ? (
              <p className="text-gray-500 text-center py-8">
                Nenhum serviço adicionado. Clique em "Adicionar Serviço" para começar.
              </p>
            ) : (
              <div className="space-y-4">
                {services.map((service, index) => (
                  <div key={service.id} className="bg-white p-6 rounded-lg shadow-sm animate-slide-in-up">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-lg font-semibold text-gray-800">Serviço {index + 1}</h4>
                      <button
                        onClick={() => removeService(service.id)}
                        disabled={isGenerating || isSending}
                        className="text-red-600 hover:text-red-700 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <i className="ri-delete-bin-line text-xl"></i>
                      </button>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Tipo de Serviço *
                        </label>
                        <select
                          value={service.name}
                          onChange={(e) => updateService(service.id, 'name', e.target.value)}
                          disabled={isGenerating || isSending}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <option value="">Selecione</option>
                          {serviceOptions.map(option => (
                            <option key={option.id} value={option.name}>
                              {option.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Quantidade *
                        </label>
                        <input
                          type="number"
                          min="1"
                          max="50"
                          value={service.quantity}
                          onChange={(e) => updateService(service.id, 'quantity', parseInt(e.target.value) || 1)}
                          disabled={isGenerating || isSending}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Materiais *
                        </label>
                        <select
                          value={service.materials}
                          onChange={(e) => updateService(service.id, 'materials', e.target.value)}
                          disabled={isGenerating || isSending}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 pr-8 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <option value="nossos">Nossos Materiais</option>
                          <option value="cliente">Materiais do Cliente (-30%)</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Subtotal
                        </label>
                        <div className="px-3 py-2 bg-gray-100 rounded-lg text-gray-800 font-semibold">
                          {service.name ? `${calculateServiceTotal(service).toLocaleString()} Kz` : '0 Kz'}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {services.length > 0 && (
            <div className="bg-blue-50 rounded-lg p-8 text-center">
              <div className="mb-6">
                <div className="text-3xl font-bold text-gray-800 mb-2">
                  Total: {calculateTotal().toLocaleString()} Kz
                </div>
                <p className="text-gray-600">
                  Valores entre 10.000 - 250.000 Kz conforme serviços e materiais
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={generateInvoice}
                  disabled={isGenerating || isSending || showInvoice}
                  className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                >
                  {isGenerating ? (
                    <>
                      <i className="ri-loader-2-line animate-spin mr-2"></i>
                      Gerando Fatura...
                    </>
                  ) : showInvoice ? (
                    <>
                      <i className="ri-check-line mr-2"></i>
                      Fatura Gerada
                    </>
                  ) : (
                    'Gerar Fatura'
                  )}
                </button>
                
                {showInvoice && invoiceStatus === 'generated' && (
                  <button
                    onClick={sendInvoiceWhatsApp}
                    disabled={isSending}
                    className="bg-green-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-700 transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                  >
                    {isSending ? (
                      <>
                        <i className="ri-loader-2-line animate-spin mr-2"></i>
                        Enviando...
                      </>
                    ) : (
                      <>
                        <i className="ri-whatsapp-line mr-2"></i>
                        Enviar Fatura
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
