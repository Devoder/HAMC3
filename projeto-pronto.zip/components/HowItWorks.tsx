'use client';

export default function HowItWorks() {
  const steps = [
    {
      number: "1",
      title: "Cliente Clica em 'Pedir Orçamento'",
      description: "O WhatsApp é aberto com mensagem automática para facilitar o contato",
      icon: "ri-smartphone-line"
    },
    {
      number: "2", 
      title: "Mensagem Automática Enviada",
      description: "\"Olá, gostaria de um orçamento para caxilharia. Aqui estão as minhas medidas: ___\"",
      icon: "ri-message-2-line"
    },
    {
      number: "3",
      title: "Resposta com Fatura Detalhada", 
      description: "Respondemos com orçamento informal detalhado (valores e materiais)",
      icon: "ri-file-text-line"
    },
    {
      number: "4",
      title: "Aprovação e Fatura Final",
      description: "Cliente aprova e enviamos fatura final com conta bancária",
      icon: "ri-check-line"
    }
  ];

  return (
    <section id="orcamento" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6 animate-fade-in">
            Como Funciona o Orçamento
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Processo simples e rápido para obter seu orçamento
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="text-center animate-slide-in-up" style={{ animationDelay: `${index * 0.2}s` }}>
              <div className="relative mb-6">
                <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 hover:bg-blue-700 transition-all duration-300 hover:scale-110">
                  <i className={`${step.icon} text-white text-2xl`}></i>
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">{step.number}</span>
                </div>
              </div>
              
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                {step.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-blue-50 rounded-lg p-8 text-center animate-slide-in-up">
          <h3 className="text-2xl font-bold text-gray-800 mb-4">
            Pronto para começar?
          </h3>
          <p className="text-gray-600 mb-6">
            Clique no botão abaixo e receba seu orçamento rapidamente
          </p>
          <button 
            onClick={() => {
              const message = encodeURIComponent("Olá, gostaria de um orçamento para caxilharia. Aqui estão as minhas medidas: ___");
              window.open(`https://wa.me/244930231558?text=${message}`, '_blank');
            }}
            className="bg-green-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-700 transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer inline-flex items-center space-x-2"
          >
            <i className="ri-whatsapp-line text-2xl"></i>
            <span>Pedir Orçamento Agora</span>
          </button>
        </div>
      </div>
    </section>
  );
}