'use client';

import Header from '@/components/Header';
import Hero from '@/components/Hero';
import ServicesList from '@/components/ServicesList';
import Portfolio from '@/components/Portfolio';
import ServiceRequest from '@/components/ServiceRequest';
import HowItWorks from '@/components/HowItWorks';
import PaymentSection from '@/components/PaymentSection';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <ServicesList />
      <Portfolio />
      <ServiceRequest />
      <HowItWorks />
      <PaymentSection />
      <Contact />
      <Footer />
      <WhatsAppButton />
    </div>
  );
}