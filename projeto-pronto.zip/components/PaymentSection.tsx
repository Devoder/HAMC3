'use client';

export default function PaymentSection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            Pagamento e Faturação
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Processo transparente e seguro para sua tranquilidade
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                <i className="ri-whatsapp-line text-green-600 text-3xl"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">
                Orçamentos pelo WhatsApp
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Todos os orçamentos e faturas são enviados diretamente pelo WhatsApp para maior praticidade e agilidade no atendimento.
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-sm">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                <i className="ri-file-text-line text-blue-600 text-3xl"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">
                Fatura Detalhada
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Receba fatura completa com nome do cliente, serviço escolhido, total a pagar e dados bancários para transferência.
              </p>
            </div>
          </div>

          <div className="bg-white p-8 rounded-lg shadow-sm">
            <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">
              A Fatura Final Inclui:
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-user-line text-orange-600 text-xl"></i>
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Nome do Cliente</h4>
                <p className="text-gray-600 text-sm">Identificação completa</p>
              </div>

              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-tools-line text-purple-600 text-xl"></i>
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Serviço Escolhido</h4>
                <p className="text-gray-600 text-sm">Descrição detalhada</p>
              </div>

              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-money-dollar-circle-line text-green-600 text-xl"></i>
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Total a Pagar</h4>
                <p className="text-gray-600 text-sm">Valor final com impostos</p>
              </div>
            </div>

            <div className="mt-8 p-6 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Formas de Pagamento</h4>
                  <p className="text-gray-600">IBAN ou Conta Bancária • QR Code (opcional)</p>
                </div>
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                  <i className="ri-bank-line text-blue-600 text-2xl"></i>
                </div>
              </div>
            </div>

            <div className="mt-6 text-center">
              <p className="text-gray-600">
                <i className="ri-time-line text-blue-600 mr-2"></i>
                Após confirmação do pagamento, definimos o prazo de execução do serviço
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}