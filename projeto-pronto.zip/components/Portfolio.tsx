'use client';

import { useState } from 'react';

export default function Portfolio() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const portfolioItems = [
    {
      title: "Janelas de Alumínio Residenciais",
      image: "https://readdy.ai/api/search-image?query=Beautiful%20residential%20aluminum%20windows%20installed%20in%20modern%20Angolan%20home%2C%20before%20and%20after%20transformation%2C%20sleek%20silver%20frames%20with%20glass%20panels%2C%20clean%20architectural%20lines%2C%20natural%20lighting%2C%20professional%20installation%20quality%2C%20contemporary%20building%20facade%20with%20excellent%20craftsmanship&width=800&height=600&seq=port-001&orientation=landscape",
      description: "Instalação completa de janelas de alumínio em residência"
    },
    {
      title: "Portas de Alumínio Comerciais",
      image: "https://readdy.ai/api/search-image?query=Commercial%20aluminum%20doors%20installation%20in%20Angola%20office%20building%2C%20modern%20glass%20entrance%20doors%20with%20aluminum%20frames%2C%20professional%20business%20entrance%2C%20sleek%20contemporary%20design%2C%20high-quality%20metallic%20finish%2C%20architectural%20precision%20and%20clean%20lines&width=800&height=600&seq=port-002&orientation=landscape",
      description: "Portas de entrada para edifícios comerciais"
    },
    {
      title: "Grades de Segurança",
      image: "https://readdy.ai/api/search-image?query=Security%20aluminum%20window%20grilles%20and%20bars%20installation%20in%20Angola%2C%20decorative%20protective%20metalwork%2C%20modern%20security%20solutions%2C%20elegant%20aluminum%20security%20frames%2C%20residential%20protection%20system%2C%20quality%20craftsmanship%20with%20clean%20finish&width=800&height=600&seq=port-003&orientation=landscape",
      description: "Grades de proteção em alumínio de alta qualidade"
    },
    {
      title: "Fachadas Completas",
      image: "https://readdy.ai/api/search-image?query=Complete%20aluminum%20facade%20installation%20in%20Angola%20commercial%20building%2C%20modern%20curtain%20wall%20system%2C%20extensive%20aluminum%20framework%2C%20professional%20architectural%20glazing%2C%20contemporary%20building%20exterior%20with%20metallic%20finish%2C%20large-scale%20caxilharia%20project&width=800&height=600&seq=port-004&orientation=landscape",
      description: "Projeto completo de fachada em alumínio"
    },
    {
      title: "Divisórias de Escritório",
      image: "https://readdy.ai/api/search-image?query=Office%20aluminum%20partitions%20and%20dividers%20installation%20in%20Angola%2C%20modern%20workplace%20glass%20partitions%20with%20aluminum%20frames%2C%20professional%20office%20interior%2C%20sleek%20contemporary%20design%2C%20transparent%20workspace%20solutions%2C%20quality%20metallic%20finish&width=800&height=600&seq=port-005&orientation=landscape",
      description: "Divisórias em alumínio para escritórios"
    },
    {
      title: "Esquadrias Personalizadas",
      image: "https://readdy.ai/api/search-image?query=Custom%20aluminum%20window%20frames%20and%20esquadrias%20in%20Angola%2C%20bespoke%20metalwork%20solutions%2C%20personalized%20aluminum%20installations%2C%20artisan%20craftsmanship%2C%20unique%20architectural%20elements%2C%20high-quality%20custom%20caxilharia%20work%20with%20precision%20finish&width=800&height=600&seq=port-006&orientation=landscape",
      description: "Esquadrias sob medida para projetos especiais"
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % portfolioItems.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + portfolioItems.length) % portfolioItems.length);
  };

  return (
    <section id="portfolio" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            Portfólio de Trabalhos
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Veja alguns dos nossos projetos realizados com qualidade e precisão
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          <div className="overflow-hidden rounded-lg shadow-lg">
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {portfolioItems.map((item, index) => (
                <div key={index} className="w-full flex-shrink-0">
                  <div className="relative">
                    <img 
                      src={item.image}
                      alt={item.title}
                      className="w-full h-96 object-cover object-top"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-end">
                      <div className="p-8 text-white">
                        <h3 className="text-2xl font-bold mb-2">{item.title}</h3>
                        <p className="text-lg">{item.description}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button 
            onClick={prevSlide}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 p-3 rounded-full shadow-lg transition-all cursor-pointer"
          >
            <i className="ri-arrow-left-line text-xl"></i>
          </button>
          
          <button 
            onClick={nextSlide}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 p-3 rounded-full shadow-lg transition-all cursor-pointer"
          >
            <i className="ri-arrow-right-line text-xl"></i>
          </button>

          <div className="flex justify-center space-x-2 mt-6">
            {portfolioItems.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-colors cursor-pointer ${
                  index === currentSlide ? 'bg-blue-600' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}